
const menuButton=document.querySelector('.menu-button');
const nav=document.querySelector('.site-nav');
menuButton?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',open);document.body.classList.toggle('menu-open',open)});
nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');document.body.classList.remove('menu-open');menuButton?.setAttribute('aria-expanded','false')}));

const filters=[...document.querySelectorAll('.filter')];
const figures=[...document.querySelectorAll('.gallery figure')];
function applyFilter(value){filters.forEach(b=>b.classList.toggle('active',b.dataset.filter===value));figures.forEach(f=>f.classList.toggle('hidden',value!=='all'&&f.dataset.category!==value));}
filters.forEach(b=>b.addEventListener('click',()=>applyFilter(b.dataset.filter)));
document.querySelectorAll('[data-jump-filter]').forEach(a=>a.addEventListener('click',()=>setTimeout(()=>applyFilter(a.dataset.jumpFilter),250)));

const lightbox=document.getElementById('lightbox');
const lbImg=lightbox?.querySelector('img');const lbText=lightbox?.querySelector('p');
figures.forEach(fig=>fig.addEventListener('click',()=>{if(!lightbox)return;const img=fig.querySelector('img');lbImg.src=img.src;lbImg.alt=img.alt;lbText.textContent=fig.querySelector('figcaption')?.textContent||'';lightbox.showModal()}));
lightbox?.querySelector('button')?.addEventListener('click',()=>lightbox.close());
lightbox?.addEventListener('click',e=>{if(e.target===lightbox)lightbox.close()});

const form=document.getElementById('inquiryForm');const status=document.getElementById('formStatus');const toast=document.getElementById('toast');
form?.addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(form);const date=fd.get('date')||'Flexible';const loc=fd.get('location')||'TBD';const details=fd.get('details')||'I would love to learn more about availability and pricing.';const message=`Hi! My name is ${fd.get('name')}. I’m interested in a ${fd.get('service')} session with Palha Shots.\n\nPreferred date: ${date}\nLocation: ${loc}\n\nDetails: ${details}`;try{await navigator.clipboard.writeText(message);status.textContent='Copied — paste this into a DM to @palhashots.';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2300)}catch{status.textContent='Copy failed on this browser. Select your details above and DM @palhashots directly.'}});
document.getElementById('year').textContent=new Date().getFullYear();
